using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Darkness
{
    class Exploration
    {
        private const string CowardlyLeapDestinationRoomId = "room-17";

        private readonly Hero hero;
        private readonly Dungeon dungeon;
        private readonly ExplorationScreen screen;
        private readonly ItemData itemData;
        private readonly MonsterData monsterData;
        private readonly SkillData skillData;
        private readonly TurnManager turnManager;
        private readonly EffectResolver effectResolver;
        private bool openingEventCompleted;

        public Exploration(Hero hero, Dungeon dungeon)
        {
            this.hero = hero;
            this.dungeon = dungeon;
            screen = new ExplorationScreen();
            itemData = new ItemData();
            monsterData = new MonsterData();
            skillData = new SkillData();
            turnManager = new TurnManager();
            effectResolver = new EffectResolver();
        }

        public GameSignal Run()
        {
            if (!openingEventCompleted)
            {
                RunOpeningEvent();
                openingEventCompleted = true;
            }

            if (EnterCurrentRoom())
            {
                return GameSignal.GAME_OVER;
            }

            while (true)
            {
                object value = screen.explorationPanel.ReadSelection();

                SkillSelection skillSelection = value as SkillSelection;
                if (skillSelection != null)
                {
                    TurnResult skillResult =
                        HandleSkillSelection(skillSelection);
                    if (skillResult != null)
                    {
                        if (ApplyTurnResult(skillResult))
                        {
                            return GameSignal.GAME_OVER;
                        }
                    }
                    continue;
                }

                ScreenSelection selection = value as ScreenSelection;
                if (selection != null)
                {
                    TurnResult selectionResult =
                        HandleScreenSelection(selection);
                    if (selectionResult != null)
                    {
                        if (ApplyTurnResult(selectionResult))
                        {
                            return GameSignal.GAME_OVER;
                        }
                    }
                    continue;
                }

                RoomDirection direction;
                if (IsExitClimb(value))
                {
                    Utility.PlayMessage(
                        "[당신은 어둠 속에서 올라왔다]");
                    return GameSignal.RETURN_TO_TITLE;
                }

                if (TryGetRoomDirection(value, out direction))
                {
                    TurnResult moveResult = turnManager.ResolveMove(
                        dungeon,
                        direction,
                        hero);
                    if (ApplyTurnResult(moveResult))
                    {
                        return GameSignal.GAME_OVER;
                    }
                    continue;
                }

                PlayerActionType action;
                if (TryGetPlayerAction(value, out action))
                {
                    TurnResult actionResult =
                        ResolvePlayerAction(action, null);
                    if (ApplyTurnResult(actionResult))
                    {
                        return GameSignal.GAME_OVER;
                    }
                }
            }
        }

        private TurnResult ResolvePlayerAction(
            PlayerActionType action,
            ItemStack itemStack,
            EquipmentSlot? itemSourceEquipmentSlot = null)
        {
            RoomSlot slot = null;
            if (PlayerActionRules.RequiresTargetSlot(action))
            {
                int slotIndex = screen.ChooseSlot();
                slot = dungeon.CurrentRoom.Slots[slotIndex];
            }

            PlayerTurnCommand command = new PlayerTurnCommand(
                action,
                slot,
                itemStack,
                null,
                itemSourceEquipmentSlot,
                true);
            return turnManager.Resolve(
                command,
                hero,
                dungeon.CurrentRoom);
        }

        private bool ApplyTurnResult(TurnResult result)
        {
            if (!result.RoomChanged &&
                result.ChangedSlotIndexes.Count > 0)
            {
                screen.RefreshRoom();
            }

            if (result.Messages.Count > 0)
            {
                Utility.PlayMessages(result.Messages.ToArray());
            }

            if (result.RoomChanged && !result.HeroDied)
            {
                return EnterCurrentRoom();
            }

            if (result.TurnCompleted && !result.HeroDied)
            {
                screen.OpenExplorationSelection();
            }

            return result.HeroDied;
        }

        private bool EnterCurrentRoom()
        {
            Room room = dungeon.CurrentRoom;
            bool isFirstEntry = !room.HasBeenEntered;
            List<string> entryStateMessages =
                ApplyRoomEntryEffects(room);
            screen.InitScreen(room, hero);
            if (entryStateMessages.Count > 0)
            {
                Utility.PlayMessages(entryStateMessages.ToArray());
                screen.OpenExplorationSelection();
            }

            if (!isFirstEntry ||
                !room.Type.ConsumesTurnOnFirstEntry)
            {
                return false;
            }

            PlayerTurnCommand command = new PlayerTurnCommand(
                PlayerActionType.Wait,
                null,
                null,
                null,
                null,
                true,
                false);
            TurnResult ambushResult = turnManager.Resolve(
                command,
                hero,
                room);
            return ApplyTurnResult(ambushResult);
        }

        private bool TryGetRoomDirection(
            object value,
            out RoomDirection direction)
        {
            if (value is ExplorationSelectionOptions &&
                (ExplorationSelectionOptions)value ==
                    ExplorationSelectionOptions.BACK)
            {
                direction = RoomDirection.BACK;
                return true;
            }

            if (value is MoveSelectionOptions)
            {
                switch ((MoveSelectionOptions)value)
                {
                    case MoveSelectionOptions.BACK:
                        direction = RoomDirection.BACK;
                        return true;
                    case MoveSelectionOptions.FORWARD:
                        direction = RoomDirection.FORWARD;
                        return true;
                    case MoveSelectionOptions.LEFT:
                        direction = RoomDirection.LEFT;
                        return true;
                    case MoveSelectionOptions.RIGHT:
                        direction = RoomDirection.RIGHT;
                        return true;
                }
            }

            direction = default(RoomDirection);
            return false;
        }

        private static bool IsExitClimb(object value)
        {
            return value is MoveSelectionOptions &&
                (MoveSelectionOptions)value ==
                    MoveSelectionOptions.CLIMB;
        }

        private bool TryGetPlayerAction(
            object value,
            out PlayerActionType action)
        {
            if (value is EncounterSelectionOptions)
            {
                EncounterSelectionOptions option =
                    (EncounterSelectionOptions)value;
                if (option == EncounterSelectionOptions.WAIT)
                {
                    action = PlayerActionType.Wait;
                    return true;
                }
                if (option == EncounterSelectionOptions.TALK)
                {
                    action = PlayerActionType.Talk;
                    return true;
                }
                if (option == EncounterSelectionOptions.THROW)
                {
                    action = PlayerActionType.ThrowItem;
                    return true;
                }
                if (option == EncounterSelectionOptions.SEARCH)
                {
                    action = PlayerActionType.Search;
                    return true;
                }
            }

            if (value is AttackSelectionOptions)
            {
                AttackSelectionOptions option =
                    (AttackSelectionOptions)value;
                if (option == AttackSelectionOptions.ATTACK)
                {
                    action = PlayerActionType.Attack;
                    return true;
                }
                if (option == AttackSelectionOptions.DEFFENSE)
                {
                    action = PlayerActionType.Defend;
                    return true;
                }
            }

            action = default(PlayerActionType);
            return false;
        }

        private void RunOpeningEvent()
        {
            MonsterType fallType = monsterData.MonsterTypes["fall"];
            Monster fall = new Monster(
                fallType,
                new Inventory(0),
                new List<ActiveEffect>(),
                new DefaultMonsterBehavior(),
                new List<string>());

            AttackContext fallAttack = new AttackContext(
                fall,
                hero,
                fallType.Attack,
                fallType.Accuracy,
                hero.Type.Evasion,
                AttackDeliveryType.Trap,
                null,
                0);
            AttackResult fallResult = AttackResolver.Resolve(fallAttack);
            DurabilityResolveResult durabilityResult =
                new DurabilityResolver().ResolveAttack(
                    fallAttack,
                    fallResult,
                    dungeon.CurrentRoom);
            Utility.PlayMessages(durabilityResult.Messages.ToArray());

            Utility.PlayMessage(CombatMessages.DamageTaken(
                fallType.Name,
                fallType.Attack.ToString()));
            Utility.PlayMessage(SkillMessages.Activated("수호의 가호"));

            TransformGuardianCharm();
            Utility.PlayMessage(EquipmentMessages.Broken("수호의 부적"));

            Utility.PlayMessages(ExplorationMessages.FirstRoomScript());
            GiveAndEquipSword();
        }

        private void TransformGuardianCharm()
        {
            ItemStack charm;
            if (!hero.Equipment.TryGetValue(EquipmentSlot.Accessory, out charm) ||
                charm == null)
            {
                return;
            }

            charm.Item.Transform(
                itemData.ItemTypes["cracked_guardian_charm"]);
        }

        private void GiveAndEquipSword()
        {
            ItemType swordType = itemData.ItemTypes["worn_sword"];
            hero.Inventory.Store(new ItemStack(new Item(swordType), 1));

            ItemStack sword = hero.Inventory.ItemStacks.Find(
                itemStack => itemStack.Item.Type.Id == swordType.Id);
            hero.Equip(EquipmentSlot.Weapon, sword);

            Utility.PlayMessage(InventoryMessages.ItemObtained(swordType.Name));
        }

        private TurnResult HandleScreenSelection(ScreenSelection selection)
        {
            if (selection.Action == ScreenAction.EquipItem &&
                selection.EquipmentSlot.HasValue)
            {
                string itemName = selection.ItemStack == null
                    ? "장비"
                    : selection.ItemStack.Item.Type.Name;
                string boundSkillId = selection.ItemStack == null
                    ? null
                    : selection.ItemStack.Item.Type.BoundSkillId;
                bool alreadyKnewSkill =
                    hero.KnowsSkill(boundSkillId);
                bool equipped = hero.Equip(
                    selection.EquipmentSlot.Value,
                    selection.ItemStack);
                List<string> messages = new List<string>
                {
                    equipped
                        ? EquipmentMessages.Equipped(itemName)
                        : EquipmentMessages.CannotEquip()
                };
                if (equipped && !alreadyKnewSkill &&
                    hero.KnowsSkill(boundSkillId))
                {
                    SkillType learnedSkill;
                    if (skillData.SkillTypes.TryGetValue(
                            boundSkillId,
                            out learnedSkill))
                    {
                        messages.Add(
                            SkillMessages.Learned(
                                learnedSkill.Name));
                    }
                }

                Utility.PlayMessages(messages.ToArray());
                screen.OpenExplorationSelection();
                return null;
            }
            else if (selection.Action == ScreenAction.UnequipItem &&
                     selection.EquipmentSlot.HasValue)
            {
                string itemName = selection.ItemStack == null
                    ? "장비"
                    : selection.ItemStack.Item.Type.Name;
                bool unequipped = hero.Unequip(
                    selection.EquipmentSlot.Value);
                Utility.PlayMessage(
                    unequipped
                        ? EquipmentMessages.Unequipped(itemName)
                        : EquipmentMessages.CannotUnequip());
                screen.OpenExplorationSelection();
                return null;
            }
            else if (selection.Action == ScreenAction.ThrowItem)
            {
                if (selection.ItemStack != null &&
                    selection.ItemStack.Count > 0)
                {
                    return ResolvePlayerAction(
                        PlayerActionType.ThrowItem,
                        selection.ItemStack,
                        selection.EquipmentSlot);
                }
            }
            else if (selection.Action == ScreenAction.UseItem)
            {
                UseItem(selection.ItemStack);
                screen.OpenExplorationSelection();
                return null;
            }

            return null;
        }

        private void UseItem(ItemStack itemStack)
        {
            if (itemStack == null || itemStack.Count <= 0 ||
                !hero.Inventory.ItemStacks.Contains(itemStack))
            {
                return;
            }

            ItemType itemType = itemStack.Item.Type;
            if (itemType.UseEffects.Count > 0)
            {
                EffectPlan plan;
                bool prepared = effectResolver.TryPrepare(
                    itemType.UseEffects,
                    EffectContext.FromItemUse(
                        hero,
                        itemStack.Item,
                        dungeon.CurrentRoom),
                    out plan);
                if (!prepared)
                {
                    Utility.PlayMessage(
                        InventoryMessages.ItemHadNoEffect(
                            itemType.Name));
                    return;
                }

                EffectResolveResult effectResult =
                    effectResolver.Execute(plan);
                if (effectResult.AffectedEffectTargets.Count > 0 &&
                    hero.Inventory.Discard(itemStack, 1) == 1)
                {
                    Utility.PlayMessage(
                        InventoryMessages.ItemUsed(itemType.Name));
                    return;
                }
            }

            if (itemType.UseFunction == ItemFunction.RestoreHealth)
            {
                const int bandageHealing = 5;
                if (hero.CurrentHealth >= hero.Type.MaxHealth)
                {
                    Utility.PlayMessage(
                        InventoryMessages.ItemHadNoEffect(
                            itemType.Name));
                    return;
                }

                if (hero.Inventory.Discard(itemStack, 1) == 1)
                {
                    int previousHealth = hero.CurrentHealth;
                    hero.RestoreHealth(bandageHealing);
                    Utility.PlayMessage(
                        InventoryMessages.HealthRestored(
                            itemType.Name,
                            hero.CurrentHealth - previousHealth));
                    return;
                }
            }

            if (itemType.UseFunction == ItemFunction.ExpandInventory &&
                hero.Inventory.Discard(itemStack, 1) == 1)
            {
                const int pocketCapacityBonus = 2;
                hero.Inventory.ExpandCapacity(pocketCapacityBonus);
                Utility.PlayMessage(
                    InventoryMessages.InventoryExpanded(
                        pocketCapacityBonus));
                return;
            }

            if (itemType.UseFunction == ItemFunction.RepairWeapon)
            {
                Item weapon = hero.GetEquippedItem(
                    EquipmentSlot.Weapon);
                if (weapon == null)
                {
                    Utility.PlayMessage(
                        InventoryMessages.CannotUseItem(
                            itemType.Name));
                    return;
                }

                if (weapon.CurrentDurability >=
                    weapon.Type.MaxDurability)
                {
                    Utility.PlayMessage(
                        InventoryMessages.ItemHadNoEffect(
                            itemType.Name));
                    return;
                }

                if (hero.Inventory.Discard(itemStack, 1) == 1)
                {
                    weapon.SetDurability(
                        weapon.Type.MaxDurability);
                    Utility.PlayMessage(
                        InventoryMessages.WeaponRepaired(
                            itemType.Name,
                            weapon.Name));
                    return;
                }
            }

            Utility.PlayMessage(
                InventoryMessages.CannotUseItem(itemType.Name));
        }

        private TurnResult HandleSkillSelection(SkillSelection selection)
        {
            SkillType skill;
            if (selection == null ||
                !skillData.SkillTypes.TryGetValue(
                    selection.SkillId,
                    out skill))
            {
                screen.OpenExplorationSelection();
                return null;
            }

            if (skill.Id == "cowardly_leap")
            {
                return ResolveCowardlyLeap(skill);
            }

            RoomSlot targetSlot = null;
            IEnumerable<object> selectedTargets = null;
            if (skill.TargetingType == SkillTargetingType.SingleSlot)
            {
                int slotIndex = screen.ChooseSlot();
                targetSlot = dungeon.CurrentRoom.Slots[slotIndex];
                if (targetSlot.Content != null)
                {
                    selectedTargets = new object[]
                    {
                        targetSlot.Content
                    };
                }
            }
            else if (skill.TargetingType != SkillTargetingType.None)
            {
                screen.OpenExplorationSelection();
                return null;
            }

            SkillUseContext skillUse = new SkillUseContext(
                hero,
                skill,
                dungeon.CurrentRoom,
                selectedTargets);
            PlayerTurnCommand command = new PlayerTurnCommand(
                PlayerActionType.UseSkill,
                targetSlot,
                null,
                skillUse,
                true);
            return turnManager.Resolve(
                command,
                hero,
                dungeon.CurrentRoom);
        }

        private TurnResult ResolveCowardlyLeap(SkillType skill)
        {
            TurnResult result = new TurnResult();
            if (!dungeon.Rooms.ContainsKey(
                    CowardlyLeapDestinationRoomId) ||
                !SkillCostResolver.TryPay(hero, skill))
            {
                result.Messages.Add(
                    SkillMessages.CannotUse(skill.Name));
                return result;
            }

            dungeon.MoveTo(CowardlyLeapDestinationRoomId);
            result.Messages.Add(
                NarrativeTemplate.Format(
                    SkillMessages.Used(skill.Name),
                    hero.Name));
            result.RoomChanged = true;
            result.TurnCompleted = true;
            return result;
        }

        private List<string> ApplyRoomEntryEffects(Room room)
        {
            List<string> messages = new List<string>();
            if (room == null)
            {
                return messages;
            }

            TurnResult roomEffectResult =
                turnManager.SynchronizeRoomEffects(room, hero);
            messages.AddRange(roomEffectResult.Messages);

            if (room.Type.RevealsAllSlotsOnEntry)
            {
                TurnResult revealResult =
                    turnManager.RevealAllSlots(room);
                messages.AddRange(revealResult.Messages);
            }

            if (room.Type.Id == "room-14" &&
                !room.HasBeenEntered)
            {
                ItemType stoneType =
                    new ItemData().ItemTypes["stone"];
                int previousCapacity = hero.Inventory.Capacity;
                int remaining =
                    hero.Inventory.StoreWithTemporaryCapacity(
                        new ItemStack(new Item(stoneType), 3),
                        stoneType.Id);
                if (remaining == 0)
                {
                    messages.Add(
                        "방에 들어서며 발치의 돌멩이 세 개를 주워 챙겼다.");
                    messages.Add(
                        InventoryMessages.ItemObtained(
                            stoneType.Name + " x3"));
                    if (hero.Inventory.Capacity > previousCapacity)
                    {
                        messages.Add(
                            "돌멩이를 보관하는 동안 소지품 칸이 임시로 1칸 늘어난다.");
                    }
                }
            }

            if (room.Type.Id != "room-4")
            {
                return messages;
            }

            int previousHealth = hero.CurrentHealth;
            int previousFocus = hero.CurrentFocus;
            hero.RestoreHealth(hero.Type.MaxHealth);
            hero.RestoreFocus(hero.Type.MaxFocus);
            messages.Add(HeroStateMessages.Restored(
                hero.CurrentHealth - previousHealth,
                hero.CurrentFocus - previousFocus));
            return messages;
        }

    }
}
